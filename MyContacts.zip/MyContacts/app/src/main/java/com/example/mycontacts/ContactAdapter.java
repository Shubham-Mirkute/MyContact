package com.example.mycontacts;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;


public class ContactAdapter extends RecyclerView.Adapter<ContactAdapter.MyViewHolder> {
    Context context;
    String[] data;
    String[] data2;
    String[] data3;
    String[] data4;
    int[] images;
    public ContactAdapter(Context ct, String[] ContactName, String[] ContactPhone, String[] ContactEmail, String[] ContactAddress, int[] img){
        context = ct;
        data=ContactName;
        data2=ContactPhone;
        data3=ContactEmail;
        data4=ContactAddress;
        images= img;
    }

    @NonNull

    @Override
    public MyViewHolder onCreateViewHolder(@NonNull  ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.contact_tile,parent,false);

        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ContactAdapter.MyViewHolder holder, int position) {
        holder.ContactName.setText(data[position]);

        holder.ContactImage.setImageResource(images[position]);

        holder.mainTile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context,ContactDeatails.class);
                intent.putExtra("data",data[position]);
//                intent.putExtra("data2",data2[position]);
//                intent.putExtra("data3",data3[position]);
//                intent.putExtra("data4",data4[position]);
                intent.putExtra("images",images[position]);

                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return images.length;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView ContactName;
        ImageView ContactImage;
        ConstraintLayout mainTile;
    public MyViewHolder(View itemView){
        super(itemView);
        ContactName = itemView.findViewById(R.id.ContactName);
        ContactImage = itemView.findViewById(R.id.ContactImage);
        mainTile = itemView.findViewById(R.id.mainTile);
    }
    }
}
